//
// C++ Interface: $WIDGETLOWER$iface
//
// Description:
//
//
// Author: Witold Wysota <wysota@wysota.eu.org>, (C) 2008
//
// Copyright: See COPYING file that comes with this distribution
//
//
#ifndef $WIDGETUPPER$IFACE_H
#define $WIDGETUPPER$IFACE_H

#include "wwinterfaces.h"

class $WIDGET$Iface : public wwWidgetInterface
{
Q_OBJECT
Q_INTERFACES(QDesignerCustomWidgetInterface);
public:
    $WIDGET$Iface(QObject *parent = 0);
    ~$WIDGET$Iface();
$CONTAINER$$DOM_DECL$$ICON_DECL$$INITIALIZE_DECL$
    QWidget *createWidget(QWidget *parent);

};

$CONTAINEREXTENSION_HEADER$
#endif
