//
// C++ Implementation: $WIDGETLOWER$iface
//
// Description:
//
//
// Author: %{AUTHOR} <%{EMAIL}>, (C) %{YEAR}
//
// Copyright: See COPYING file that comes with this distribution
//
//
#include "$WIDGETLOWER$iface.h"
#include "$WIDGETLOWER$.h"

$WIDGET$face::$WIDGET$Iface(QObject *parent) : wwWidgetInterface(parent){}


$WIDGET$Iface::~$WIDGET$Iface() {}

QWidget * $WIDGET$Iface::createWidget(QWidget * parent) {
    return new $WIDGET$(parent);
}

$ICON_IMPL$
$DOM_IMPL$
$INITIALIZE_IMPL$

$CONTAINEREXTENSION_IMPLEMENTATION$
