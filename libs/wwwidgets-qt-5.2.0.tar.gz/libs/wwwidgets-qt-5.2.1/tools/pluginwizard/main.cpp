//
// C++ Implementation: %{MODULE}
//
// Description:
//
//
// Author: %{AUTHOR} <%{EMAIL}>, (C) %{YEAR}
//
// Copyright: See COPYING file that comes with this distribution
//
//
#include <QApplication>
#include "pluginwizard.h"
#include <QFile>
#include <QVariant>


/*
    "podszablony"
    $TEMPLATE_:/filename.template$
 */

QString fetchAndReplace(const QString &tempFileName, const QMap<QString,QString> &convMap);

QString &replaceAll(QString &string, const QMap<QString, QString> &convMap) {
    for (QMap<QString,QString>::const_iterator iter = convMap.begin(); iter!=convMap.end(); ++iter)
        string.replace(QRegExp("\\$"+iter.key()+"\\$"), iter.value());
    // replace subtemplates
    QRegExp rx("\\$TEMPLATE_(.*)\\$");
    rx.setMinimal(true);
    while (rx.indexIn(string)>=0) {
        QString templateName = rx.cap(1);
        QString templateContents = fetchAndReplace(templateName, convMap);
        string.replace(rx.cap(0), templateContents);
    }
    // strip all unreplaced tags
    QRegExp strip("\\$.*\\$");
    strip.setMinimal(true);
    string.replace(strip, "");
    return string;
}

QString fetchAndReplace(const QString &tempFileName, const QMap<QString,QString> &convMap) {
    QFile inFile(tempFileName);
    if (!inFile.open(QFile::ReadOnly|QFile::Text))
        return QString();
    QString data = inFile.readAll();
    inFile.close();
    data = replaceAll(data, convMap);
    return data;
}


#include <QtDebug>

class TagMap : public QMap<QString,QString> {
public:
  void assign(const QString &tag, const QString &val){
    insert(tag.toUpper(), val);
  }
  void assignTemplate(const QString &tag, const QString &templ){
    insert(tag.toUpper(), "$TEMPLATE_"+templ+"$");
  }
};

void populate(const QString &out, const QString &in, const QMap<QString,QString> &map) {
    QString tempStr = fetchAndReplace(in, map);
    QFile outF(out);
    if (!outF.open(QFile::WriteOnly))
        return;
    outF.write(tempStr.toLocal8Bit());
    outF.close();
}

int main(int argc, char **argv) {
    QApplication app(argc, argv);
    PluginWizard wizard;

    if (wizard.exec()) {
        QMap<QString, QString> smallTags;
        QFile stF(":/templates/smalltags.txt");
        stF.open(QFile::ReadOnly|QFile::Text);
        while(!stF.atEnd()){
            QString line  = stF.readLine();
            QStringList tokens = line.split(": ");
            tokens[1].chop(1);
            smallTags.insert(tokens[0], tokens[1]);
        }
        stF.close();
        QString clN = wizard.field("className").toString();
        QString targetDir = wizard.field("targetDir").toString();
        TagMap convMap;
        convMap["WIDGET"] = clN;
        convMap["WIDGETLOWER"] = clN.toLower();
        convMap["WIDGETUPPER"] = clN.toUpper();
        convMap["BASECLASS"] = "QWidget";
        convMap["ADDPAGEMETHOD"] = wizard.field("addWidget").toString();
        convMap["INSERTPAGEMETHOD"] = wizard.field("insertWidget").toString();
        convMap["REMOVEPAGEMETHOD"] = wizard.field("remove").toString();
        convMap["COUNTMETHOD"] = wizard.field("count").toString();
        convMap["PAGEMETHOD"] = wizard.field("widget").toString();
        convMap["CURRENTINDEXMETHOD"] = wizard.field("currentIndex").toString();
        convMap["SETCURRENTINDEXMETHOD"] = wizard.field("setCurrentIndex").toString();
        if (wizard.field("container").toBool()) {
            convMap.assignTemplate("CONTAINER", ":/templates/iscontainer.template");
            if (wizard.field("containerExt").toBool()) {
                convMap["DOM_DECL"] = smallTags["DOM_DECL"]+"\n";
                convMap.assignTemplate("DOM_IMPL", ":/domxml.template");
                convMap.assign("REGISTER_CONTAINEREXTENSION", smallTags["REGISTER_CONTAINEREXTENSION"]);
                convMap.assignTemplate("INITIALIZE_IMPL", ":/templates/initialize.template");
                convMap.assign("INITIALIZE_DECL", smallTags["INITIALIZE_DECL"]+"\n");

                convMap.assignTemplate("CONTAINEREXTENSION_HEADER", ":/templates/containerext_header.template");
                convMap.assignTemplate("CONTAINEREXTENSION_IMPLEMENTATION", ":/templates/containerext_implementation.template");
            }
        }
        QString ic = wizard.field("icon").toString();
        if (!ic.isEmpty()) {
            convMap.insert("ICON_DECL", smallTags["ICON_DECL"]+"\n");
            convMap.insert("ICON_IMPL", QString("QIcon %1::icon() const { return QPixmap(\"%2\"); }\n").arg(clN).arg(ic));
        }
        populate(targetDir+"/"+clN.toLower()+"iface.h", ":/template.h", convMap);
        populate(targetDir+"/"+clN.toLower()+"iface.cpp", ":/template.cpp", convMap);

    }
    return 0;
}
