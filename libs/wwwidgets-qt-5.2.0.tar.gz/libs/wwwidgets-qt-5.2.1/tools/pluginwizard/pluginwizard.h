//
// C++ Interface: pluginwizard
//
// Description:
//
//
// Author: Witold Wysota <wysota@wysota.eu.org>, (C) 2008
//
// Copyright: See COPYING file that comes with this distribution
//
//
#ifndef PLUGINWIZARD_H
#define PLUGINWIZARD_H

#include <QWizard>

/**
	@author Witold Wysota <wysota@wysota.eu.org>
*/
class PluginWizard : public QWizard
{
Q_OBJECT
public:
    enum { Intro = 0, Widget = 1, Container = 2, Destination,
    Summary };
    PluginWizard(QWidget *parent = 0);
    int nextId () const;
    ~PluginWizard();

};



#endif
