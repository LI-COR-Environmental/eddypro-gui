//
// C++ Implementation: %{MODULE}
//
// Description:
//
//
// Author: %{AUTHOR} <%{EMAIL}>, (C) %{YEAR}
//
// Copyright: See COPYING file that comes with this distribution
//
//
#include "pluginwizard.h"
#include "ui_widgetpage.h"
#include "ui_intropage.h"
#include "ui_summarypage.h"
#include "ui_containerpage.h"

#include <QwwFileChooser>

class IntroPage : public QWizardPage, private Ui::IntroPage {
public:
    IntroPage() : QWizardPage(){
        setupUi(this);
        setTitle("Introduction");
    }
};


class WidgetPage : public QWizardPage {
public:
    WidgetPage() : QWizardPage(){
        setTitle("Widget Page");
        setSubTitle("Enter widget data");
        ui.setupUi(this);
        registerField("className*", ui.widgetclass);
        registerField("container", ui.containerWidget);
        registerField("containerExt", ui.containerExtension);
        registerField("taskmenuExt", ui.taskmenuExtension);
        registerField("icon", ui.icon);
    }
    QString className() const { return ui.widgetclass->text(); }
    QString iconPath() const { return ui.icon->text(); }
    bool isContainer() const { return ui.containerWidget->isChecked(); }
    bool hasContainerExtension() const { return ui.containerWidget->isChecked() && ui.containerExtension->isChecked(); }
    bool hasTaskMenuExtension() const { return ui.taskmenuExtension->isChecked(); }
private:
    Ui::WidgetPage ui;
};

class ContainerPage : public QWizardPage {
public:
    ContainerPage() : QWizardPage() {
        setTitle("Container extension");
        setSubTitle("Enter data for creating the container extension");
        ui.setupUi(this);
        registerField("addWidget", ui.addWidget);
        registerField("insertWidget", ui.insertWidget);
        registerField("widget", ui.widget);
        registerField("remove", ui.remove);
        registerField("count", ui.count);
        registerField("currentIndex", ui.currentIndex);
        registerField("setCurrentIndex", ui.setCurrentIndex);
    }
    void cleanupPage(){}
private:
    Ui::ContainerPage ui;
};

class DestinationPage : public QWizardPage {
public:
    DestinationPage() : QWizardPage() {
        setTitle("Choose destination");
        setSubTitle("Please choose the destination directory for the plugin");
        QHBoxLayout *l = new QHBoxLayout(this);
        QwwFileChooser *ch = new QwwFileChooser;

        ch->setFileMode(QFileDialog::Directory);
        ch->setText(QDir::currentPath());
        l->addWidget(ch);
        registerField("targetDir", ch);
    }
};

class SummaryPage : public QWizardPage {
public:
    SummaryPage() : QWizardPage(){
        ui.setupUi(this);
        setTitle("Summary");
        setSubTitle("Please check your data before continuing");
    }
    void initializePage (){
        ui.widget->setText(field("className").toString());
        ui.container->setText(field("container").toBool() ? "true" : "false");
        ui.containerExt->setText((field("container").toBool() && field("containerExt").toBool()) ? "true" : "false");
        ui.destination->setText(field("targetDir").toString());
        QPixmap px(field("icon").toString());
        ui.icon->setPixmap(px);
    }
private:
    Ui::SummaryPage ui;
};

PluginWizard::PluginWizard(QWidget *parent)
 : QWizard(parent)
{
    setPage(Intro,          new IntroPage);
    setPage(Widget,         new WidgetPage);
    setPage(Container,      new ContainerPage);
    setPage(Destination,    new DestinationPage);
    setPage(Summary,        new SummaryPage);
    setPixmap(QWizard::LogoPixmap, QPixmap(":/logo.png").scaled(QSize(137,137), Qt::KeepAspectRatio));
    setButtonText(QWizard::FinishButton, "Create plugin");
}


PluginWizard::~PluginWizard()
{
}

int PluginWizard::nextId() const
{
    if(currentId()==Widget && (field("container").toBool() == false || field("containerExt").toBool()==false))
        return Destination;
    return QWizard::nextId();
}
